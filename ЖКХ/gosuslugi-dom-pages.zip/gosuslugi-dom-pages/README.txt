Госуслуги Дом — публикация инструкции

Главный файл сайта: index.html

Для GitHub Pages:
1. Создайте новый PUBLIC-репозиторий.
2. Загрузите index.html в корень репозитория (не ZIP-файл).
3. Откройте Settings → Pages.
4. В разделе Build and deployment выберите Deploy from a branch.
5. Выберите ветку main и папку /(root), нажмите Save.
6. Дождитесь публикации. Адрес сайта будет показан в Settings → Pages.

Внимание: сайт GitHub Pages будет общедоступным в интернете.
